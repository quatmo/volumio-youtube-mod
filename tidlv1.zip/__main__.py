# -*- coding: utf-8 -*-
import sys
sys.path.append('./')
import tidal_dl
if __name__ == '__main__':
    # tidal_dl.debug()
    tidal_dl.main(sys.argv)

    

