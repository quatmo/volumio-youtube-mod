# tidal-upmpdcli-plugin-for-volumio2
Plugin to install and configure the streaming service foor Tidal with upmpdcli daemon in Volumio 2
